import ply.yacc as yacc
from lexer import *
# Parsing rules
def p_program(p):
    '''program : ENJOY MAIN LPAREN RPAREN LBRACE statements RBRACE'''
    p[0] = ('main', p[6])

def p_statements(p):
    '''statements : statements statement
                  | statement'''
    if len(p) == 3:
        p[0] = p[1] + [p[2]]
    else:
        p[0] = [p[1]]

def p_statement_print(p):
    '''statement : PRINT LPAREN STRING RPAREN'''
    p[0] = ('print', p[3])

def p_statement_assign(p):
    '''statement : ID EQUALS expression'''
    p[0] = ('assign', p[1], p[3])

def p_expression_binop(p):
    '''expression : expression PLUS term
                  | expression MINUS term'''
    p[0] = ('binop', p[2], p[1], p[3])

def p_expression_term(p):
    '''expression : term'''
    p[0] = p[1]

def p_term_binop(p):
    '''term : term TIMES factor
            | term DIVIDE factor'''
    p[0] = ('binop', p[2], p[1], p[3])

def p_term_factor(p):
    '''term : factor'''
    p[0] = p[1]

def p_factor_num(p):
    '''factor : NUMBER'''
    p[0] = ('num', p[1])

def p_factor_id(p):
    '''factor : ID'''
    p[0] = ('id', p[1])

def p_error(p):
    print("Syntax error at '%s'" % p.value if p else "Syntax error at EOF")



# Build the parser
parser = yacc.yacc()
