import os
import pyfiglet

def read_log_file(filename="cookie_hotpot_log.txt"):
    if os.path.isfile(filename):
        try:
            with open(filename, 'r') as file:
                content = file.read()
            return content
        except Exception as e:
            print(f"Error reading log file: {e}")
            return None
    else:
        return "No log entries found."

if __name__ == "__main__":
    result = pyfiglet.figlet_format("HotPot")
    print(result)
    print("Welcome to Cookie HotPot! <3")
    log_entries = read_log_file()
    if log_entries:
        print("Log Entries:")
        print(log_entries)
    else:
        print("No log entries found.")
