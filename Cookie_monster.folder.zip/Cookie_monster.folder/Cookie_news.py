import os
import time

def read_news_from_file(filename="cookie_news.txt"):
    if os.path.isfile(filename):
        try:
            with open(filename, 'r') as file:
                content = file.read()
            return content
        except Exception as e:
            print(f"Error reading news file: {e}")
            return None
    else:
        return "No news available."

if __name__ == "__main__":
    print("Welcome to Cookie News! <3")
    while True:
        news = read_news_from_file()
        print("Latest News and Updates:")
        print(news)
        time.sleep(30)  # Refresh news every 2 seconds
